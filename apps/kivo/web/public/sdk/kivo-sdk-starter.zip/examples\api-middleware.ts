import { createServer } from 'node:http';
import { createKivoFromEnv } from '../src/kivo.js';

const kivo = createKivoFromEnv();
const resource = '/premium/weather-risk-score';

createServer(async (request, response) => {
  if (request.url !== resource) {
    response.writeHead(404).end('Not found');
    return;
  }

  const paid = request.headers['x-kivo-paid'] === 'true';

  if (!paid) {
    const checkout = kivo.buildCheckoutSession({
      resource,
      amount: '0.05',
      assetCode: process.env.KIVO_DEFAULT_ASSET ?? 'USDC',
    });

    response.writeHead(402, {
      'content-type': 'application/json',
      'x-kivo-checkout-url': checkout.checkoutUrl,
    });
    response.end(JSON.stringify({ error: 'payment_required', checkoutUrl: checkout.checkoutUrl }));
    return;
  }

  response.writeHead(200, { 'content-type': 'application/json' });
  response.end(JSON.stringify({ score: 87, unlockedBy: 'kivo' }));
}).listen(8787, () => {
  console.log('API premium em http://localhost:8787/premium/weather-risk-score');
});
