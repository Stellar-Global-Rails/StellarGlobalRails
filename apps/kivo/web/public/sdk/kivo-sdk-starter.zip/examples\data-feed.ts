import { createKivoFromEnv } from '../src/kivo.js';

const kivo = createKivoFromEnv();

const resource = 'feed/telemetry/machine-42';

await kivo.createPricingRule({
  resource,
  amount: '0.02',
  assetCode: process.env.KIVO_DEFAULT_ASSET ?? 'USDC',
  description: 'Leitura autenticada de telemetria industrial.',
});

await kivo.subscribeWebhook({
  url: 'https://seu-backend.com/kivo/webhook',
  events: ['payment.confirmed', 'payment.failed'],
});

console.log('Feed pronto para cobrar:', kivo.buildCheckoutSession({ resource, amount: '0.02' }).checkoutUrl);
