# Kivo SDK Starter

Starter para conectar um device, API ou data feed ao Kivo Solo MVP.

## O que vem aqui

- `src/kivo.ts`: cliente HTTP pequeno para a API do Kivo.
- `examples/device-gateway.ts`: exemplo para gateway IoT ou device.
- `examples/api-middleware.ts`: exemplo para proteger uma rota premium.
- `examples/data-feed.ts`: exemplo para vender um feed de dados.
- `.env.example`: variaveis esperadas no backend do seu produto.

## Instalar

```bash
npm install
cp .env.example .env
```

Depois preencha:

```bash
KIVO_API_URL=https://SEU-PROJETO.supabase.co/functions/v1/kivo-api
KIVO_API_KEY=kv_live_ou_test_...
KIVO_CHECKOUT_BASE_URL=https://seu-front.vercel.app/checkout
```

## Regra importante

Nunca coloque `KIVO_API_KEY` dentro de app mobile, browser ou firmware publico. Use a chave no seu servidor, gateway, edge function ou backend do device.

## Fluxo recomendado

1. Crie um flow no painel Kivo.
2. Baixe este starter.
3. Gere uma API key no painel.
4. Proteja seu recurso usando um dos exemplos.
5. Teste em `/checkout`.
6. Publique para seus usuarios.
