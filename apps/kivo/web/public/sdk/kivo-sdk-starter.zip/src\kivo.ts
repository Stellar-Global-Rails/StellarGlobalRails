export type KivoAssetCode = 'USDC' | 'XLM' | string;

export interface KivoClientConfig {
  apiUrl: string;
  apiKey: string;
  checkoutBaseUrl?: string;
}

export interface KivoPricingRuleInput {
  resource: string;
  amount: string;
  assetCode?: KivoAssetCode;
  description?: string;
}

export interface KivoDeviceInput {
  name: string;
  metadata?: Record<string, string>;
}

export interface KivoPaymentInput {
  fromDeviceId?: string;
  toDeviceId?: string;
  amount: string;
  assetCode?: KivoAssetCode;
  memo?: string;
  conditionType?: 'none' | 'energy_kwh' | 'time_elapsed' | 'service_complete';
  conditionValue?: string;
}

export interface KivoCheckoutSession {
  resource: string;
  amount: string;
  assetCode: KivoAssetCode;
  checkoutUrl: string;
}

export class KivoClient {
  private readonly apiUrl: string;
  private readonly apiKey: string;
  private readonly checkoutBaseUrl: string;

  constructor(config: KivoClientConfig) {
    if (!config.apiUrl || !config.apiKey) {
      throw new Error('KIVO_API_URL e KIVO_API_KEY sao obrigatorios.');
    }

    this.apiUrl = config.apiUrl.replace(/\/$/, '');
    this.apiKey = config.apiKey;
    this.checkoutBaseUrl = config.checkoutBaseUrl ?? 'http://localhost:5174/checkout';
  }

  async createDevice(input: KivoDeviceInput) {
    return this.request('/v1/devices', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  async createPricingRule(input: KivoPricingRuleInput) {
    return this.request('/v1/x402/pricing-rules', {
      method: 'PUT',
      body: JSON.stringify({
        resource: input.resource,
        amount: input.amount,
        assetCode: input.assetCode ?? 'USDC',
        description: input.description,
      }),
    });
  }

  async createPayment(input: KivoPaymentInput) {
    return this.request('/v1/payments', {
      method: 'POST',
      body: JSON.stringify({
        ...input,
        assetCode: input.assetCode ?? 'USDC',
        conditionType: input.conditionType ?? 'service_complete',
      }),
    });
  }

  async createChallenge(resource: string) {
    return this.request(`/v1/x402/challenge?resource=${encodeURIComponent(resource)}`);
  }

  async subscribeWebhook(input: { url: string; events: string[] }) {
    return this.request('/v1/webhooks', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  }

  buildCheckoutSession(input: KivoPricingRuleInput): KivoCheckoutSession {
    const assetCode = input.assetCode ?? 'USDC';
    const url = new URL(this.checkoutBaseUrl);
    url.searchParams.set('resource', input.resource);
    url.searchParams.set('amount', input.amount);
    url.searchParams.set('asset', assetCode);

    return {
      resource: input.resource,
      amount: input.amount,
      assetCode,
      checkoutUrl: url.toString(),
    };
  }

  private async request(path: string, init: RequestInit = {}) {
    const response = await fetch(`${this.apiUrl}${path}`, {
      ...init,
      headers: {
        'content-type': 'application/json',
        authorization: `Bearer ${this.apiKey}`,
        ...init.headers,
      },
    });

    const body = await response.text();
    const data = body ? JSON.parse(body) : null;

    if (!response.ok) {
      throw new Error(data?.error ?? data?.message ?? `Kivo API error ${response.status}`);
    }

    return data;
  }
}

export function createKivoFromEnv(env = process.env) {
  return new KivoClient({
    apiUrl: String(env.KIVO_API_URL ?? ''),
    apiKey: String(env.KIVO_API_KEY ?? ''),
    checkoutBaseUrl: String(env.KIVO_CHECKOUT_BASE_URL ?? ''),
  });
}
