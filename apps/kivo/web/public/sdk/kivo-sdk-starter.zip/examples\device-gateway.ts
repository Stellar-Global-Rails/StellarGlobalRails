import { createKivoFromEnv } from '../src/kivo.js';

const kivo = createKivoFromEnv();

const resource = 'charger-a/session';

await kivo.createPricingRule({
  resource,
  amount: '0.10',
  assetCode: process.env.KIVO_DEFAULT_ASSET ?? 'USDC',
  description: 'Sessao de recarga cobrada por minuto.',
});

const checkout = kivo.buildCheckoutSession({
  resource,
  amount: '0.10',
  assetCode: process.env.KIVO_DEFAULT_ASSET ?? 'USDC',
});

console.log('Envie o usuario para:', checkout.checkoutUrl);
